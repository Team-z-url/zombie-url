module.exports = {
	cookieKey: 'djsiadisaudshOIJODSAJIjdisoaojoidsa',
	googleClientID:
		'925033032731-4as0p5s8h19s9443bftjpluthq602rbu.apps.googleusercontent.com',
	googleClientSecret: 'ow9EAHVaO8z3wSvDCH_r_LMb'
};
